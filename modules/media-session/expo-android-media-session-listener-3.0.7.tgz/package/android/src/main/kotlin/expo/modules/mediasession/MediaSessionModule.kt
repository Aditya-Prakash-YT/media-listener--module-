package expo.modules.mediasession

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import android.content.ComponentName
import android.content.Intent
import android.provider.Settings
import android.os.Bundle
import android.media.session.PlaybackState
import android.util.Log

class MediaSessionModule : Module() {
    companion object {
        private const val TAG = "MediaSessionModule"
    }

    override fun definition() = ModuleDefinition {
        Name("MediaSession")

        Events("onMediaChanged")

        Function("requestPermission") {
            val intent = Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }

        Function("hasPermission") {
            val packageName = context.packageName
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
                ?: return@Function false
            val names = flat.split(":")
            for (name in names) {
                val component = ComponentName.unflattenFromString(name)
                if (component != null && component.packageName == packageName) {
                    return@Function true
                }
            }
            return@Function false
        }

        Function("play") {
            MediaSessionService.activeController?.transportControls?.play()
        }

        Function("pause") {
            MediaSessionService.activeController?.transportControls?.pause()
        }

        Function("skipNext") {
            MediaSessionService.activeController?.transportControls?.skipToNext()
        }

        Function("skipPrevious") {
            MediaSessionService.activeController?.transportControls?.skipToPrevious()
        }

        Function("seekTo") { position: Long ->
            MediaSessionService.activeController?.transportControls?.seekTo(position)
        }

        Function("getState") {
            val controller = MediaSessionService.activeController
            if (controller == null) return@Function null
            
            val metadata = controller.metadata
            val state = controller.playbackState
            
            val stateString = when (state?.state) {
                PlaybackState.STATE_PLAYING -> "playing"
                PlaybackState.STATE_PAUSED -> "paused"
                PlaybackState.STATE_STOPPED -> "stopped"
                PlaybackState.STATE_BUFFERING -> "buffering"
                else -> "unknown"
            }

            // Use shared helper — single source of truth for artwork resolution
            val artworkUri = try {
                ArtworkHelper.resolveArtworkUri(controller, context.cacheDir)
            } catch (e: Exception) {
                Log.e(TAG, "Error resolving artwork in getState", e)
                null
            }
            
            val result = mutableMapOf<String, Any?>(
                "package" to controller.packageName,
                "title" to (metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: ""),
                "artist" to (metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: ""),
                "album" to (metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ALBUM) ?: ""),
                "state" to stateString,
                "position" to (state?.position ?: 0L),
                "duration" to (metadata?.getLong(android.media.MediaMetadata.METADATA_KEY_DURATION) ?: 0L)
            )

            if (artworkUri != null) {
                result["artworkUri"] = artworkUri
            }

            result
        }

        OnStartObserving {
            MediaEventManager.setListener { bundle ->
                sendEvent("onMediaChanged", bundleToMap(bundle))
            }
        }

        OnStopObserving {
            MediaEventManager.setListener(null)
        }
    }

    private fun bundleToMap(bundle: Bundle): Map<String, Any?> {
        val map = mutableMapOf<String, Any?>()
        for (key in bundle.keySet()) {
            map[key] = bundle.get(key)
        }
        return map
    }

    private val context
        get() = requireNotNull(appContext.reactContext) { "React Application Context is null" }
}
